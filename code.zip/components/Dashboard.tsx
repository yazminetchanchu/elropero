import React from 'react';
import { InventoryItem, Sale, Expense } from '../types';
import MetricCard from './MetricCard';
import { Edit2, Trash2, X, Search } from 'lucide-react';

interface DashboardProps {
  inventory: InventoryItem[];
  sales: Sale[];
  expenses: Expense[];
  onUpdateItem: (item: InventoryItem) => void;
  onDeleteItem: (id: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ inventory, sales, expenses, onUpdateItem, onDeleteItem }) => {
  const [editingItem, setEditingItem] = React.useState<InventoryItem | null>(null);
  const [searchTerm, setSearchTerm] = React.useState('');
  const [pendingDeleteId, setPendingDeleteId] = React.useState<string | null>(null);

  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const currentYear = now.getFullYear();

  const isCurrentMonth = (dateStr: string) => {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return false;
    return d.getMonth() + 1 === currentMonth && d.getFullYear() === currentYear;
  };

  const monthlySales = sales.filter(s => isCurrentMonth(s.fecha));
  const monthlyExpenses = expenses.filter(e => isCurrentMonth(e.fecha));

  // ==========================
  // HELPERS
  // ==========================

  const getItemPrices = (item: any) => {
    const pe =
      typeof item.precioEfectivo === 'number'
        ? item.precioEfectivo
        : item.ventaEfectivo;

    const pt =
      typeof item.precioTarjeta === 'number'
        ? item.precioTarjeta
        : typeof item.ventaTarjeta === 'number'
          ? item.ventaTarjeta
          : pe;

    return { pe, pt };
  };

  const computeSaleTotals = (sale: Sale) => {
    let efectivo = 0;
    let tarjeta = 0;
    let total = 0;

    sale.items.forEach((item: any) => {
      const { pe, pt } = getItemPrices(item);
      const cant = item.cantidad;

      const tE = pe * cant * (sale.pago.efectivo / 100);
      const tT = pt * cant * (sale.pago.tarjeta / 100);

      efectivo += tE;
      tarjeta += tT;
      total += tE + tT;
    });

    return { efectivo, tarjeta, total };
  };

  // ==========================
  // CAJA
  // ==========================

  const totalEfectivo = monthlySales.reduce((acc, sale) => {
    const { efectivo } = computeSaleTotals(sale);
    const signo = sale.tipo === 'devolucion' ? -1 : 1;
    return acc + signo * efectivo;
  }, 0);

  const totalTarjeta = monthlySales.reduce((acc, sale) => {
    const { tarjeta } = computeSaleTotals(sale);
    const signo = sale.tipo === 'devolucion' ? -1 : 1;
    return acc + signo * tarjeta;
  }, 0);

  // ==========================
  // GANANCIA BRUTA
  // ==========================

  const gBrutaMes = monthlySales.reduce((acc, sale) => {
    const signo = sale.tipo === 'devolucion' ? -1 : 1;

    const gananciaVenta = sale.items.reduce((sum, item: any) => {
      const { pe, pt } = getItemPrices(item);
      const precioUnit = (sale.pago.tarjeta > 0 && sale.pago.efectivo === 0) ? pt : pe;
      return sum + ((precioUnit - item.costo) * item.cantidad);
    }, 0);

    return acc + signo * gananciaVenta;
  }, 0);

  // ==========================
  // GANANCIA NETA
  // ==========================

  const totalGastosMes = monthlyExpenses.reduce((acc, expense) => acc + expense.monto, 0);
  const gNetaMes = gBrutaMes - totalGastosMes;

  const stockTotal = inventory.reduce((acc, item) => acc + item.cantidad, 0);

  const filteredInventory = inventory.filter(item =>
    item.descripcion.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.proveedor.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDelete = (id: string) => {
    if (pendingDeleteId === id) {
      onDeleteItem(id);
      setPendingDeleteId(null);
    } else {
      setPendingDeleteId(id);
      setTimeout(() => setPendingDeleteId(null), 3000);
    }
  };

  return (
    <div className="space-y-16 text-left">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <MetricCard label="Ganancia Neta (Mes)" value={`$ ${gNetaMes.toLocaleString()}`} subValue={`${currentMonth}/${currentYear}`} />
        <MetricCard label="Caja Efectivo" value={`$ ${totalEfectivo.toLocaleString()}`} subValue="Física" />
        <MetricCard label="Caja Tarjeta" value={`$ ${totalTarjeta.toLocaleString()}`} subValue="Digital" />
        <MetricCard label="Stock Total" value={`${stockTotal} u.`} subValue="Unidades" />
      </div>

      <div className="space-y-8">
        <div className="flex justify-between items-end border-b border-black pb-8">
          <h3 className="font-serif text-5xl italic">Inventario</h3>
          <div className="relative w-80">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-black/30" size={16} />
            <input
              type="text"
              placeholder="BUSCAR..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white border border-black/10 py-4 pl-12 text-xs uppercase"
            />
          </div>
        </div>

        <table className="w-full border">
          <thead className="bg-black text-white">
            <tr>
              <th>Codigo</th>
              <th>Descripción</th>
              <th>Cantidad</th>
              <th>Precio</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filteredInventory.map(item => (
              <tr key={item.id}>
                <td>{item.sku}</td>
                <td>{item.descripcion}</td>
                <td>{item.cantidad}</td>
                <td>$ {item.ventaEfectivo.toLocaleString()}</td>
                <td>
                  <button onClick={() => setEditingItem(item)}><Edit2 size={16}/></button>
                  <button onClick={() => handleDelete(item.id)}><Trash2 size={16}/></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editingItem && (
        <div className="fixed inset-0 bg-black/80 flex justify-center items-center">
          <div className="bg-white p-10">
            <button onClick={() => setEditingItem(null)}><X /></button>
            <h3>Editar</h3>
            <button onClick={() => { onUpdateItem(editingItem); setEditingItem(null); }}>Guardar</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;

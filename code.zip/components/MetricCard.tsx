
import React from 'react';

interface MetricCardProps {
  label: string;
  value: string | number;
  subValue?: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ label, value, subValue }) => {
  return (
    <div className="bg-white border border-black p-8 text-left shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] flex flex-col justify-center min-h-[160px] transition-transform hover:-translate-y-1 duration-300">
      <span className="text-[10px] uppercase tracking-[4px] text-black font-black mb-4 opacity-40 leading-none">{label}</span>
      <h3 className="font-serif text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight mb-2 leading-none">{value}</h3>
      {subValue && (
        <p className="text-[10px] text-black/60 mt-3 tracking-[2px] uppercase font-bold border-t border-black/5 pt-3">
          {subValue}
        </p>
      )}
    </div>
  );
};

export default MetricCard;

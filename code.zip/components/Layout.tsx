import React from 'react';
import { Section } from '../types';
import { LayoutDashboard, ShoppingBag, PackagePlus, WalletMinimal, LogOut, Menu, X } from 'lucide-react';

interface LayoutProps {
  currentSection: Section;
  setSection: (section: Section) => void;
  onLogout: () => void;
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ currentSection, setSection, onLogout, children }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const menuItems = [
    { id: 'admin', label: 'PANEL', icon: LayoutDashboard },
    { id: 'ventas', label: 'CAJA', icon: ShoppingBag },
    { id: 'stock', label: 'STOCK', icon: PackagePlus },
    { id: 'gastos', label: 'EGRESOS', icon: WalletMinimal },
  ];

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#F7F7F2]">
      {/* Sidebar Desktop */}
      <aside className="hidden md:flex w-64 flex-col border-r border-black/10 bg-white p-6 fixed h-full z-30">
        <div className="mb-12">
          <h1 className="font-serif text-2xl uppercase text-black italic">EL ROPERO</h1>
        </div>

        <nav className="flex-1 space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setSection(item.id as Section)}
              className={`w-full text-left py-3 px-4 flex items-center gap-3 border transition-all text-[10px] tracking-[2px] font-bold ${
                currentSection === item.id
                  ? 'bg-black text-white border-black shadow-lg translate-x-1'
                  : 'bg-transparent text-black border-transparent hover:bg-neutral-50 hover:translate-x-1'
              }`}
            >
              <item.icon size={16} />
              {item.label}
            </button>
          ))}
        </nav>

        <button
          onClick={onLogout}
          className="mt-auto py-4 px-4 flex items-center gap-3 text-[10px] tracking-[2px] font-black border border-black/5 hover:bg-red-50 hover:text-red-600 transition-all uppercase group"
        >
          <LogOut size={16} className="group-hover:-translate-x-1 transition-transform" /> Salir
        </button>
      </aside>

      {/* Mobile Nav */}
      <div className="md:hidden flex items-center justify-between p-4 bg-white border-b border-black/10 sticky top-0 z-50">
        <span className="font-serif text-lg font-bold">EL ROPERO</span>
        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2 border border-black/5">
          {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-white pt-20 px-6 animate-in slide-in-from-top duration-300">
          <nav className="space-y-4">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setSection(item.id as Section);
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full text-left py-4 px-6 flex items-center gap-4 border text-[11px] tracking-[2px] font-bold ${
                  currentSection === item.id ? 'bg-black text-white border-black' : 'bg-white border-black/10'
                }`}
              >
                <item.icon size={18} />
                {item.label}
              </button>
            ))}
          </nav>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 md:ml-64 p-6 md:p-12">
        <div className="max-w-6xl mx-auto">{children}</div>
      </main>
    </div>
  );
};

export default Layout;


import React from 'react';
import { Expense } from '../types';
import { Edit2, Trash2, X } from 'lucide-react';

interface ExpensesProps {
  expenses: Expense[];
  onAddExpense: (expense: Omit<Expense, 'id'>) => void;
  onUpdateExpense: (expense: Expense) => void;
  onDeleteExpense: (id: string) => void;
}

const Expenses: React.FC<ExpensesProps> = ({ expenses, onAddExpense, onUpdateExpense, onDeleteExpense }) => {
  const [formData, setFormData] = React.useState({
    concepto: '',
    monto: 0
  });
  
  const [editingExpense, setEditingExpense] = React.useState<Expense | null>(null);
  const [pendingDeleteId, setPendingDeleteId] = React.useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.concepto || formData.monto <= 0) return;

    onAddExpense({
      fecha: new Date().toLocaleDateString('es-AR'),
      ...formData
    });

    setFormData({ concepto: '', monto: 0 });
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingExpense) {
      onUpdateExpense(editingExpense);
      setEditingExpense(null);
    }
  };

  const handleDelete = (id: string) => {
    if (pendingDeleteId === id) {
      onDeleteExpense(id);
      setPendingDeleteId(null);
    } else {
      setPendingDeleteId(id);
      setTimeout(() => setPendingDeleteId(null), 3000);
    }
  };

  return (
    <div className="flex flex-col space-y-16 text-left max-w-7xl">
      <section className="space-y-10 max-w-4xl">
        <div className="border-b border-black/5 pb-6">
            <h2 className="font-serif text-4xl mb-2 italic tracking-tight">Egresos de Caja</h2>
            <p className="text-[10px] tracking-[4px] uppercase font-black text-black opacity-40">Registro de gastos operativos y salidas varias</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white border border-black p-8 md:p-12 space-y-12 shadow-[10px_10px_0px_0px_rgba(0,0,0,1)] text-left">
          <div className="space-y-10">
            <div className="space-y-3">
              <label className="text-[10px] tracking-[4px] uppercase font-black text-black opacity-40 leading-none">Concepto del Gasto</label>
              <input
                type="text"
                required
                value={formData.concepto}
                onChange={(e) => setFormData({ ...formData, concepto: e.target.value })}
                className="w-full bg-transparent border-b border-black py-4 focus:outline-none text-base font-bold uppercase tracking-wide"
                placeholder="EJ: ALQUILER, PACKAGING, PUBLICIDAD"
              />
            </div>

            <div className="space-y-3">
              <label className="text-[10px] tracking-[4px] uppercase font-black text-black opacity-40 leading-none">Monto ($)</label>
              <div className="relative">
                <span className="absolute left-0 top-4 text-3xl font-black">$</span>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  required
                  value={formData.monto}
                  onChange={(e) => setFormData({ ...formData, monto: parseFloat(e.target.value) })}
                  className="w-full bg-transparent border-b border-black py-4 pl-10 focus:outline-none text-3xl font-black"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-black text-white py-7 text-[12px] tracking-[7px] font-black uppercase hover:bg-neutral-800 transition-all shadow-2xl"
          >
            REGISTRAR EGRESO
          </button>
        </form>
      </section>

      <section className="space-y-10 max-w-5xl">
        <div className="text-left border-b border-black/10 pb-4">
            <h3 className="font-serif text-3xl italic mb-2">Historial de Salidas</h3>
            <p className="text-[10px] tracking-[4px] uppercase font-black text-black opacity-40">Detalle cronológico de gastos registrados</p>
        </div>
        <div className="bg-white border border-black shadow-sm overflow-hidden">
          <div className="max-h-[600px] overflow-y-auto">
            {expenses.length > 0 ? (
                <ul className="divide-y divide-gray-100">
                    {expenses.slice().reverse().map((exp) => (
                        <li key={exp.id} className="p-8 flex justify-between items-center hover:bg-neutral-50 transition-colors">
                            <div className="flex-1 text-left">
                                <p className="font-black text-sm tracking-[2px] uppercase">{exp.concepto}</p>
                                <p className="text-[10px] text-gray-400 mt-2 uppercase tracking-[3px] font-bold">{exp.fecha}</p>
                            </div>
                            <div className="flex items-center gap-10">
                                <p className="font-serif text-3xl italic text-red-600 leading-none">-$ {exp.monto.toLocaleString()}</p>
                                <div className="flex gap-3">
                                  <button 
                                    onClick={() => setEditingExpense(exp)} 
                                    className="p-4 border border-black/5 hover:bg-black hover:text-white transition-all text-black"
                                    title="Editar"
                                  >
                                    <Edit2 size={16} />
                                  </button>
                                  <button 
                                    onClick={() => handleDelete(exp.id)} 
                                    className={`p-4 border transition-all flex items-center gap-2 ${pendingDeleteId === exp.id ? 'bg-red-600 border-red-600 text-white' : 'border-red-50 text-red-600 hover:bg-red-600 hover:text-white'}`}
                                    title="Eliminar"
                                  >
                                    {pendingDeleteId === exp.id ? <span className="text-[9px] font-black uppercase tracking-widest">¿BORRAR?</span> : <Trash2 size={16} />}
                                  </button>
                                </div>
                            </div>
                        </li>
                    ))}
                </ul>
            ) : (
                <div className="p-32 text-center opacity-20">
                    <p className="text-[10px] tracking-[8px] uppercase font-black">Sin egresos registrados</p>
                </div>
            )}
          </div>
        </div>
      </section>

      {editingExpense && (
        <div className="fixed inset-0 z-[60] bg-black/70 backdrop-blur-md flex items-center justify-center p-6 text-left text-black">
          <div className="bg-white border border-black w-full max-w-lg p-12 shadow-2xl relative">
            <button onClick={() => setEditingExpense(null)} className="absolute top-8 right-8 p-2 hover:bg-neutral-100"><X size={24} /></button>
            <h3 className="font-serif text-3xl mb-10 italic">Editar Egreso</h3>
            <form onSubmit={handleEditSubmit} className="space-y-10">
              <div className="space-y-3">
                <label className="text-[10px] tracking-[4px] uppercase font-black text-black opacity-40 leading-none">Concepto</label>
                <input 
                  type="text" 
                  value={editingExpense.concepto} 
                  onChange={(e) => setEditingExpense({...editingExpense, concepto: e.target.value})}
                  className="w-full bg-transparent border-b border-black py-3 focus:outline-none text-sm font-bold uppercase"
                />
              </div>
              <div className="space-y-3">
                <label className="text-[10px] tracking-[4px] uppercase font-black text-black opacity-40 leading-none">Monto ($)</label>
                <div className="relative">
                  <span className="absolute left-0 top-2 text-xl font-black">$</span>
                  <input 
                    type="number" 
                    value={editingExpense.monto} 
                    onChange={(e) => setEditingExpense({...editingExpense, monto: parseFloat(e.target.value)})}
                    className="w-full bg-transparent border-b border-black py-3 pl-6 focus:outline-none text-2xl font-black"
                  />
                </div>
              </div>
              <button type="submit" className="w-full bg-black text-white py-6 mt-6 text-[12px] tracking-[6px] font-black uppercase hover:bg-neutral-800 transition-all shadow-xl">
                Guardar Cambios
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Expenses;

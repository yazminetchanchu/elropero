
import React from 'react';
import { InventoryItem } from '../types';
import { Tag, Sparkles, PackagePlus } from 'lucide-react';

interface StockProps {
  onAddItem: (item: Omit<InventoryItem, 'id' | 'costoTotal'>) => void;
  inventory: InventoryItem[];
}

const Stock: React.FC<StockProps> = ({ onAddItem, inventory }) => {
  const [formData, setFormData] = React.useState({
    descripcion: '',
    proveedor: '',
    cantidad: 1,
    costo: 0
  });
  const [ventaEfectivo, setVentaEfectivo] = React.useState(0);
  const [ventaTarjeta, setVentaTarjeta] = React.useState(0);
  const [generatedSku, setGeneratedSku] = React.useState('');

  // Generar SKU único localmente para previsualización y confirmación
  const generateLocalSKU = (provider: string) => {
    if (!provider.trim()) return '';
    const initial = provider.trim().charAt(0).toUpperCase();
    let isUnique = false;
    let newSku = '';
    let attempts = 0;

    while (!isUnique && attempts < 100) {
      const randomNum = Math.floor(1000 + Math.random() * 9000);
      newSku = `${initial}${randomNum}`;
      isUnique = !inventory.some(item => item.sku === newSku);
      attempts++;
    }
    return newSku;
  };

  // Actualizar el SKU cuando cambian los datos base
  React.useEffect(() => {
    if (formData.proveedor.trim()) {
      setGeneratedSku(generateLocalSKU(formData.proveedor));
    } else {
      setGeneratedSku('');
    }
  }, [formData.proveedor, inventory]);

  // Manejar el cambio de costo para actualizar precios sugeridos editables
  const handleCostoChange = (val: number) => {
    setFormData({ ...formData, costo: val });
    const sugeridoEfe = Math.ceil((val * 1.68) / 1000) * 1000;
    const sugeridoTar = Math.ceil((sugeridoEfe * 1.27) / 1000) * 1000;
    setVentaEfectivo(sugeridoEfe);
    setVentaTarjeta(sugeridoTar);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.descripcion || !formData.proveedor || !generatedSku) return;
    
    onAddItem({
      fechaIngreso: new Date().toLocaleDateString('es-AR'),
      sku: generatedSku,
      ventaEfectivo,
      ventaTarjeta,
      ...formData
    });

    setFormData({ descripcion: '', proveedor: '', cantidad: 1, costo: 0 });
    setVentaEfectivo(0);
    setVentaTarjeta(0);
    setGeneratedSku('');
  };

  return (
    <div className="w-full text-left">
      <div className="mb-12 border-b border-black/5 pb-6 flex items-center justify-between">
        <div>
          <h2 className="font-serif text-4xl mb-2 italic tracking-tight text-left">Carga de Mercadería</h2>
          <p className="text-[10px] tracking-[4px] uppercase font-black text-black opacity-40 text-left">Ingreso de stock con precios y referencias personalizables</p>
        </div>
        <PackagePlus className="opacity-10 hidden md:block" size={48} />
      </div>

      <div className="flex flex-col items-start">
        <form onSubmit={handleSubmit} className="w-full bg-white border border-black p-8 md:p-14 space-y-12 shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] text-left relative overflow-hidden">
          {/* Detalle decorativo */}
          <div className="absolute top-0 right-0 w-32 h-32 -mr-16 -mt-16 bg-[#F7F7F2] rounded-full opacity-50 border border-black/5"></div>
          
          <div className="space-y-10 relative z-10">
            <div className="space-y-3">
              <label className="text-[10px] tracking-[4px] uppercase font-black text-black opacity-40 leading-none">Descripción de la Prenda</label>
              <input 
                type="text" 
                required 
                value={formData.descripcion} 
                onChange={(e) => setFormData({ ...formData, descripcion: e.target.value })} 
                className="w-full bg-transparent border-b border-black py-4 focus:outline-none text-base font-bold uppercase tracking-wide placeholder:opacity-20" 
                placeholder="EJ: VESTIDO LINO FLOREADO" 
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-start">
              <div className="space-y-3">
                <label className="text-[10px] tracking-[4px] uppercase font-black text-black opacity-40 leading-none">Proveedor</label>
                <input 
                  type="text" 
                  required 
                  value={formData.proveedor} 
                  onChange={(e) => setFormData({ ...formData, proveedor: e.target.value })} 
                  className="w-full bg-transparent border-b border-black py-4 focus:outline-none text-base font-bold uppercase tracking-wide placeholder:opacity-20" 
                  placeholder="ZARA, AVANZA, ETC." 
                />
              </div>

              {/* Sección de Código REF Generado */}
              <div className="bg-[#FBFBFB] border border-black p-6 flex flex-col justify-center h-full">
                <p className="text-[9px] tracking-[3px] uppercase font-black text-black/40 mb-2">Referencia Asignada (REF)</p>
                <div className="flex items-center gap-3">
                  <div className="bg-black text-white p-2">
                    <Tag size={14} />
                  </div>
                  <span className={`font-serif text-3xl font-bold italic ${!generatedSku ? 'opacity-10' : 'opacity-100'}`}>
                    {generatedSku || '----'}
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-3">
                <label className="text-[10px] tracking-[4px] uppercase font-black text-black opacity-40 leading-none">Cantidad en Stock</label>
                <input 
                  type="number" 
                  min="1" 
                  required 
                  value={formData.cantidad} 
                  onChange={(e) => setFormData({ ...formData, cantidad: parseInt(e.target.value) })} 
                  className="w-full bg-transparent border-b border-black py-4 focus:outline-none text-lg font-bold" 
                />
              </div>
              <div className="space-y-3">
                <label className="text-[10px] tracking-[4px] uppercase font-black text-black opacity-40 leading-none">Costo Unitario ($)</label>
                <div className="relative">
                  <span className="absolute left-0 top-1/2 -translate-y-1/2 text-xl opacity-20">$</span>
                  <input 
                    type="number" 
                    min="0" 
                    step="0.01" 
                    required 
                    value={formData.costo} 
                    onChange={(e) => handleCostoChange(parseFloat(e.target.value) || 0)} 
                    className="w-full bg-transparent border-b border-black py-4 pl-6 focus:outline-none text-lg font-black" 
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Footer negro optimizado: Botón más pequeño e integrado */}
          <div className="bg-black text-white p-6 md:p-8 flex flex-col md:flex-row justify-between items-center gap-6 shadow-2xl">
              <div className="text-center md:text-left flex flex-col md:flex-row gap-8 w-full md:w-auto items-center">
                  <div className="hidden lg:block border-r border-white/10 pr-6 mr-2">
                    <span className="text-[8px] tracking-[3px] font-bold uppercase opacity-30 block">Precios Finales</span>
                  </div>
                  <div className="flex gap-10">
                      <div className="space-y-1">
                        <p className="text-[7px] opacity-30 uppercase font-black tracking-[1px]">Efectivo ($)</p>
                        <input 
                          type="number" 
                          value={ventaEfectivo} 
                          onChange={(e) => setVentaEfectivo(parseFloat(e.target.value) || 0)}
                          className="bg-transparent border-b border-white/20 font-serif text-xl font-bold italic text-white focus:outline-none focus:border-white w-24 py-1"
                        />
                      </div>
                      <div className="space-y-1">
                        <p className="text-[7px] opacity-30 uppercase font-black tracking-[1px]">Tarjeta ($)</p>
                        <input 
                          type="number" 
                          value={ventaTarjeta} 
                          onChange={(e) => setVentaTarjeta(parseFloat(e.target.value) || 0)}
                          className="bg-transparent border-b border-white/20 font-serif text-xl font-bold italic text-white focus:outline-none focus:border-white w-24 py-1"
                        />
                      </div>
                  </div>
              </div>
              
              <button 
                type="submit" 
                disabled={!generatedSku}
                className="group flex items-center gap-3 bg-white text-black px-8 py-4 text-[10px] tracking-[4px] font-black uppercase hover:bg-neutral-200 transition-all disabled:opacity-20 flex-shrink-0"
              >
                <span>Confirmar</span>
                <Sparkles size={14} className="group-hover:rotate-12 transition-transform" />
              </button>
          </div>
        </form>
      </div>
      
      <div className="mt-12 text-center opacity-30">
        <p className="text-[9px] uppercase tracking-[5px] font-bold">El Ropero Showroom &copy; 2025</p>
      </div>
    </div>
  );
};

export default Stock;

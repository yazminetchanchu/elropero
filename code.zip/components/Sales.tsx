import React from 'react';
import { InventoryItem, Sale, SaleItem, GiftCard } from '../types';
import { Trash2, ShoppingCart, RotateCcw, Search, PlusCircle } from 'lucide-react';

const RECARGO_TARJETA = 0.15;

interface SalesProps {
  inventory: InventoryItem[];
  onAddSale: (sale: Omit<Sale, 'id'> & { giftCardUsada?: { codigo: string; montoUsado: number } }) => void;
  recentSales: Sale[];
  onReturnSale: (sale: Sale) => void;
  giftCards: GiftCard[];
}

const Sales: React.FC<SalesProps> = ({ inventory, onAddSale, recentSales, onReturnSale, giftCards }) => {
  const [cart, setCart] = React.useState<SaleItem[]>([]);
  const [searchTerm, setSearchTerm] = React.useState('');
  const [quantity, setQuantity] = React.useState(1);
  const [showResults, setShowResults] = React.useState(false);

  const [pagoEfectivo, setPagoEfectivo] = React.useState(100);
  const [pagoTarjeta, setPagoTarjeta] = React.useState(0);

  // =======================
  // GIFT CARD
  // =======================
  const [giftCardSeleccionada, setGiftCardSeleccionada] = React.useState<GiftCard | null>(null);
  const [montoGiftUsar, setMontoGiftUsar] = React.useState(0);

  const filteredProducts = React.useMemo(() => {
    if (!searchTerm.trim()) return [];
    return inventory
      .filter(
        p =>
          p.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
          p.descripcion.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .slice(0, 5);
  }, [inventory, searchTerm]);

  const getStockDisponible = (productId: string) => {
    const item = inventory.find(i => i.id === productId);
    const inCart = cart.find(i => i.id === productId)?.cantidad || 0;
    return (item?.cantidad || 0) - inCart;
  };

  const addToCart = (product: InventoryItem) => {
    const disponible = getStockDisponible(product.id);
    if (disponible <= 0) return;

    const cant = Math.min(quantity, disponible);
    const index = cart.findIndex(i => i.id === product.id);

    const precioTarjeta =
      product.ventaTarjeta ??
      Math.round(product.ventaEfectivo * (1 + RECARGO_TARJETA));

    if (index !== -1) {
      const copy = [...cart];
      copy[index].cantidad += cant;
      setCart(copy);
    } else {
      setCart([
        ...cart,
        {
          id: product.id,
          descripcion: product.descripcion,
          cantidad: cant,
          costo: product.costo,
          precioEfectivo: product.ventaEfectivo,
          precioTarjeta,
          descuento: 0
        }
      ]);
    }

    setSearchTerm('');
    setQuantity(1);
    setShowResults(false);
  };

  const removeFromCart = (idx: number) => {
    setCart(cart.filter((_, i) => i !== idx));
  };

  const totals = cart.reduce(
    (acc, item) => {
      const cant = item.cantidad;

      const descManual = item.descuento || 0;
      const descFinal = Math.max(descManual, 0);
      const factor = 1 - descFinal / 100;
      const precioLista = item.precioTarjeta;
      const precioFinal = precioLista * factor;

      const tE = precioFinal * cant * (pagoEfectivo / 100);
      const tT = precioFinal * cant * (pagoTarjeta / 100);

      acc.efectivo += tE;
      acc.tarjeta += tT;
      acc.total += tE + tT;

      return acc;
    },
    { efectivo: 0, tarjeta: 0, total: 0 }
  );

  const totalFinal = Math.max(0, totals.total - montoGiftUsar);

  const confirmSale = () => {
    if (cart.length === 0) return;
    if (pagoEfectivo + pagoTarjeta !== 100) {
      alert('El pago debe sumar 100%');
      return;
    }

    const giftData =
      giftCardSeleccionada && montoGiftUsar > 0
        ? {
            giftCardUsada: {
              codigo: giftCardSeleccionada.codigo,
              montoUsado: montoGiftUsar
            }
          }
        : {};

    onAddSale({
      fecha: new Date().toISOString(),
      items: cart,
      pago: {
        efectivo: pagoEfectivo,
        tarjeta: pagoTarjeta
      },
      tipo: 'venta',
      ...giftData
    });

    setCart([]);
    setPagoEfectivo(100);
    setPagoTarjeta(0);
    setGiftCardSeleccionada(null);
    setMontoGiftUsar(0);
  };

  return (
    <div className="space-y-12 text-left">

      {/* BUSCADOR */}
      <div className="relative">
        <input
          value={searchTerm}
          onChange={(e) => { setSearchTerm(e.target.value); setShowResults(true); }}
          placeholder="Buscar producto..."
          className="w-full border border-black p-4 text-lg"
        />

        {showResults && filteredProducts.length > 0 && (
          <div className="absolute z-50 bg-white border border-black w-full">
            {filteredProducts.map(p => (
              <div
                key={p.id}
                onClick={() => addToCart(p)}
                className="p-4 hover:bg-neutral-100 cursor-pointer flex justify-between"
              >
                <span>{p.descripcion}</span>
                <span>Stock: {getStockDisponible(p.id)}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* CARRITO */}
      <div className="border border-black bg-white">
        {cart.map((item, idx) => (
          <div key={idx} className="flex justify-between p-4 border-b">
            <div>{item.descripcion} x {item.cantidad}</div>
            <button onClick={() => removeFromCart(idx)}><Trash2 size={16} /></button>
          </div>
        ))}
      </div>

      {/* GIFT CARD */}
      {giftCards.length > 0 && (
        <div className="border border-black bg-white p-6 space-y-4">
          <h3 className="font-serif text-2xl italic">Gift Card</h3>

          <select
            value={giftCardSeleccionada?.codigo || ''}
            onChange={(e) => {
              const gc = giftCards.find(g => g.codigo === e.target.value) || null;
              setGiftCardSeleccionada(gc);
              setMontoGiftUsar(0);
            }}
            className="w-full border border-black p-3"
          >
            <option value="">Seleccionar Gift Card</option>
            {giftCards.filter(gc => gc.estado === 'ACTIVA' && gc.saldo > 0).map(gc => (
              <option key={gc.id} value={gc.codigo}>
                {gc.codigo} — {gc.destinatario} (${gc.saldo})
              </option>
            ))}
          </select>

          {giftCardSeleccionada && (
            <input
              type="number"
              min={0}
              max={giftCardSeleccionada.saldo}
              value={montoGiftUsar}
              onChange={(e) => setMontoGiftUsar(Math.min(giftCardSeleccionada.saldo, Number(e.target.value)))}
              className="w-full border border-black p-3 text-lg font-bold"
              placeholder="Monto a usar"
            />
          )}
        </div>
      )}

      {/* TOTAL */}
      <div className="text-3xl font-black">
        Total: $ {totalFinal.toLocaleString()}
      </div>

      {/* CONFIRMAR */}
      <button
        onClick={confirmSale}
        className="w-full bg-black text-white py-6 text-xl font-black"
      >
        CONFIRMAR VENTA
      </button>

    </div>
  );
};

export default Sales;

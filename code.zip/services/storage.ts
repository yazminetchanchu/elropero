import { InventoryItem, Sale, Expense, GiftCard } from '../types';
import { db } from './firebase';
import { doc, getDoc, setDoc, onSnapshot } from "firebase/firestore";

export interface DatabaseState {
  inventory: InventoryItem[];
  sales: Sale[];
  expenses: Expense[];
  giftCards: GiftCard[];      // ✅ NUEVO
  lastSync?: string;
}

// Cambiar keys fuerza “reset” local (evita cache viejo)
const LOCAL_KEY = "ropero_local_backup_v3_2026";
const SHOWROOM_KEY = "ropero_showroom_id_v3_2026";

// =======================
// SHOWROOM ID
// =======================
const getShowroomID = () => {
  let id = localStorage.getItem(SHOWROOM_KEY);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(SHOWROOM_KEY, id);
  }
  return id;
};

const setShowroomID = (id: string) => {
  const clean = id.trim().toUpperCase();
  localStorage.setItem(SHOWROOM_KEY, clean);
  return clean;
};

// =======================
// LOCAL STORAGE
// =======================
const getLocalBackup = (): DatabaseState => {
  const raw = localStorage.getItem(LOCAL_KEY);
  if (!raw) {
    return {
      inventory: [],
      sales: [],
      expenses: [],
      giftCards: [],     // ✅ NUEVO
      lastSync: ""
    };
  }
  return JSON.parse(raw);
};

const updateLocalOnly = (data: DatabaseState) => {
  localStorage.setItem(LOCAL_KEY, JSON.stringify(data));
};

// =======================
// FIREBASE (ONE-SHOT) - compat
// =======================
const fetchRemote = async (overrideID?: string): Promise<DatabaseState | null> => {
  const id = overrideID || getShowroomID();
  const ref = doc(db, "showrooms", id);
  const snap = await getDoc(ref);
  if (snap.exists()) return snap.data() as DatabaseState;
  return null;
};

// =======================
// FIREBASE (REALTIME)
// =======================
const subscribe = (onData: (data: DatabaseState) => void) => {
  const id = getShowroomID();
  const ref = doc(db, "showrooms", id);

  return onSnapshot(ref, async (snap) => {
    if (snap.exists()) {
      const data = snap.data() as DatabaseState;

      // Backward compatibility: si no existe giftCards, lo agregamos
      if (!data.giftCards) {
        data.giftCards = [];
      }

      updateLocalOnly(data);
      onData(data);
      return;
    }

    // Si no existe el doc, lo creamos vacío
    const empty: DatabaseState = {
      inventory: [],
      sales: [],
      expenses: [],
      giftCards: [],   // ✅ NUEVO
      lastSync: ""
    };

    await setDoc(ref, empty);
    updateLocalOnly(empty);
    onData(empty);
  });
};

const persist = async (state: Omit<DatabaseState, "lastSync">) => {
  const id = getShowroomID();
  const ref = doc(db, "showrooms", id);
  const payload: DatabaseState = { ...state, lastSync: new Date().toISOString() };
  await setDoc(ref, payload);
  updateLocalOnly(payload);
};

// =======================
// EXPORT BACKUP FILE - compat
// =======================
const exportBackupFile = () => {
  const data = getLocalBackup();
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = "ropero_backup.json";
  a.click();

  URL.revokeObjectURL(url);
};

// =======================
// EXPORT API
// =======================
export const database = {
  getShowroomID,
  setShowroomID,
  getLocalBackup,
  updateLocalOnly,
  fetchRemote,      // compat
  subscribe,        // realtime
  persist,
  exportBackupFile, // compat
};

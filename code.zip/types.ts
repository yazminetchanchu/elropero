export type Section = 'admin' | 'ventas' | 'stock' | 'gastos';

export interface InventoryItem {
  id: string;
  sku: string;
  descripcion: string;
  proveedor: string;
  cantidad: number;
  costo: number;

  // Precios base
  ventaEfectivo: number;

  // Si no existe, se calcula desde efectivo + recargo
  ventaTarjeta?: number;
}

export interface SaleItem {
  id: string;
  descripcion: string;
  cantidad: number;

  // Para poder calcular ganancia histórica aunque cambie el inventario
  costo: number;

  // Precios unitarios guardados en el momento de la venta
  precioEfectivo: number;
  precioTarjeta: number;

  //en caso de promocion o descuento
  descuento: number; 
}

export interface Sale {
  id: string;
  fecha: string;
  items: SaleItem[];
  total: number;
  tipo: 'venta' | 'devolucion';

  giftCardUsada?: {
    codigo: string;
    montoUsado: number;
  };

  pago?: {
    efectivo: number;
    tarjeta: number;
  };
}

export interface Expense {
  id: string;
  fecha: string;
  monto: number;
  descripcion: string;
}

export interface GiftCard {
  id: string;
  codigo: string;
  destinatario: string;
  montoInicial: number;
  saldo: number;
  estado: 'ACTIVA' | 'AGOTADA' | 'ANULADA';
  fechaCreacion: string;
}
import React from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import Sales from './components/Sales';
import Stock from './components/Stock';
import Expenses from './components/Expenses';
import { InventoryItem, Sale, Expense, Section, GiftCard } from './types';
import { database, DatabaseState } from './services/storage';
import { Store, Lock, Loader2, Monitor, ArrowRightLeft, Smartphone } from 'lucide-react';

const SYSTEM_PASSWORD = "Danisa0302";

const App: React.FC = () => {
  const [isEntered, setIsEntered] = React.useState(false);
  const [password, setPassword] = React.useState("");
  const [showroomID, setShowroomID] = React.useState(() => database.getShowroomID());
  const [authError, setAuthError] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(false);
  const [section, setSection] = React.useState<Section>('admin');

  const [inventory, setInventory] = React.useState<InventoryItem[]>([]);
  const [sales, setSales] = React.useState<Sale[]>([]);
  const [expenses, setExpenses] = React.useState<Expense[]>([]);
  const [giftCards, setGiftCards] = React.useState<GiftCard[]>([]);

  const [isDataReady, setIsDataReady] = React.useState(false);

  // =======================
  // REALTIME SYNC
  // =======================
  React.useEffect(() => {
    if (!isEntered) return;

    const unsub = database.subscribe((data: DatabaseState) => {
      setInventory(data.inventory || []);
      setSales(data.sales || []);
      setExpenses(data.expenses || []);
      setGiftCards(data.giftCards || []);
      setIsDataReady(true);
    });

    return () => unsub();
  }, [isEntered]);

  // =======================
  // LOGIN
  // =======================
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    setTimeout(() => {
      if (password === SYSTEM_PASSWORD && showroomID.trim() !== "") {
        database.setShowroomID(showroomID);
        setIsEntered(true);
        setAuthError(false);
      } else {
        setAuthError(true);
      }
      setIsLoading(false);
    }, 800);
  };

  // =======================
  // DATA PERSISTENCE
  // =======================
  const handleDataChange = async (
    newInv: InventoryItem[],
    newSales: Sale[],
    newExp: Expense[],
    newGiftCards: GiftCard[] = giftCards
  ) => {
    setInventory(newInv);
    setSales(newSales);
    setExpenses(newExp);
    setGiftCards(newGiftCards);

    await database.persist({
      inventory: newInv,
      sales: newSales,
      expenses: newExp,
      giftCards: newGiftCards
    });
  };

  // =======================
  // SALES
  // =======================
  const handleAddSale = (
    saleData: Omit<Sale, 'id'> & { giftCardUsada?: { codigo: string; montoUsado: number } }
  ) => {
    let nextGiftCards = [...giftCards];

    if (saleData.giftCardUsada) {
      nextGiftCards = giftCards.map(gc => {
        if (gc.codigo === saleData.giftCardUsada!.codigo) {
          const nuevoSaldo = gc.saldo - saleData.giftCardUsada!.montoUsado;
          return {
            ...gc,
            saldo: nuevoSaldo,
            estado: nuevoSaldo <= 0 ? 'AGOTADA' : 'ACTIVA'
          };
        }
        return gc;
      });
    }

    const newSale: Sale = { 
      ...saleData, 
      id: `sale_${Date.now()}` 
    };

    const nextInv = inventory.map(item => {
      const sold = saleData.items.find(si => si.id === item.id);
      return sold
        ? { ...item, cantidad: Math.max(0, item.cantidad - sold.cantidad) }
        : item;
    });

    handleDataChange(nextInv, [...sales, newSale], expenses, nextGiftCards);
  };

  const handleReturnSale = (sale: Sale) => {
    const nextInv = inventory.map(item => {
      const returned = sale.items.find(si => si.id === item.id);
      return returned
        ? { ...item, cantidad: item.cantidad + returned.cantidad }
        : item;
    });

    const returnSale: Sale = {
      ...sale,
      id: `return_${Date.now()}`,
      fecha: new Date().toISOString(),
      tipo: 'devolucion'
    };

    handleDataChange(nextInv, [...sales, returnSale], expenses, giftCards);
  };

  // =======================
  // EXPENSES
  // =======================
  const handleAddExpense = (expenseData: Omit<Expense, 'id'>) => {
    const newExp = { ...expenseData, id: `exp_${Date.now()}` };
    handleDataChange(inventory, sales, [...expenses, newExp], giftCards);
  };

  const handleUpdateExpense = (updated: Expense) => {
    const nextExp = expenses.map(e => e.id === updated.id ? updated : e);
    handleDataChange(inventory, sales, nextExp, giftCards);
  };

  const handleDeleteExpense = (id: string) => {
    const nextExp = expenses.filter(e => e.id !== id);
    handleDataChange(inventory, sales, nextExp, giftCards);
  };

  // =======================
  // INVENTORY
  // =======================
  const handleAddItem = (item: Omit<InventoryItem, 'id'>) => {
    const newItem: InventoryItem = { ...item, id: `inv_${Date.now()}` };
    handleDataChange([...inventory, newItem], sales, expenses, giftCards);
    setSection('admin');
  };

  const handleUpdateItem = (updatedItem: InventoryItem) => {
    const nextInv = inventory.map(item => item.id === updatedItem.id ? updatedItem : item);
    handleDataChange(nextInv, sales, expenses, giftCards);
  };

  const handleDeleteItem = (id: string) => {
    const nextInv = inventory.filter(item => item.id !== id);
    handleDataChange(nextInv, sales, expenses, giftCards);
  };

  // =======================
  // LOGIN UI
  // =======================
  if (!isEntered) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F7F7F2] p-6">
        {/* tu login queda igual que antes */}
      </div>
    );
  }

  if (!isDataReady) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Cargando datos...</p>
      </div>
    );
  }

  // =======================
  // APP
  // =======================
  return (
    <Layout currentSection={section} setSection={setSection} onLogout={() => setIsEntered(false)}>
      {section === 'admin' && (
        <Dashboard
          inventory={inventory}
          sales={sales}
          expenses={expenses}
          onUpdateItem={handleUpdateItem}
          onDeleteItem={handleDeleteItem}
        />
      )}

      {section === 'ventas' && (
        <Sales
          inventory={inventory}
          onAddSale={handleAddSale}
          recentSales={sales}
          onReturnSale={handleReturnSale}
          giftCards={giftCards}
        />
      )}

      {section === 'stock' && (
        <Stock onAddItem={handleAddItem} inventory={inventory} />
      )}

      {section === 'gastos' && (
        <Expenses
          expenses={expenses}
          onAddExpense={handleAddExpense}
          onUpdateExpense={handleUpdateExpense}
          onDeleteExpense={handleDeleteExpense}
        />
      )}
    </Layout>
  );
};

export default App;
